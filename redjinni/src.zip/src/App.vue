<template>
  <router-view></router-view>
</template>

<script>

export default {
  name: 'App',
 
}
</script>

<style>
* {
    font-family: 'Poppins';
    margin: 0;
    padding: 0;
    text-decoration: none;
    box-sizing: border-box;
}</style>
